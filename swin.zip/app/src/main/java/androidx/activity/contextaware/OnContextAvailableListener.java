package androidx.activity.contextaware;

import android.content.Context;
/* loaded from: classes.dex */
public interface OnContextAvailableListener {
    void onContextAvailable(Context context);
}
