package androidx.activity.result;
/* loaded from: classes.dex */
public interface ActivityResultCallback<O> {
    void onActivityResult(O o);
}
