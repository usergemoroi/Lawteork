package androidx.activity;

import android.window.OnBackInvokedCallback;
/* compiled from: D8$$SyntheticClass */
/* loaded from: classes.dex */
public final /* synthetic */ class OnBackPressedDispatcher$Api33Impl$$ExternalSyntheticLambda0 implements OnBackInvokedCallback {
    public final /* synthetic */ Runnable f$0;

    public final void onBackInvoked() {
        this.f$0.run();
    }
}
