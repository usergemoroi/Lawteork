package androidx.activity;
/* renamed from: androidx.activity.R */
/* loaded from: classes2.dex */
public final class C0019R {

    /* renamed from: androidx.activity.R$id */
    /* loaded from: classes2.dex */
    public static final class C0020id {
        public static final int view_tree_on_back_pressed_dispatcher_owner = 2131296736;

        private C0020id() {
        }
    }

    private C0019R() {
    }
}
