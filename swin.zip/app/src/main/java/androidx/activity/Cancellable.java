package androidx.activity;
/* loaded from: classes.dex */
interface Cancellable {
    void cancel();
}
