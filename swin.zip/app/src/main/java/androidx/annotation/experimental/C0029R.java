package androidx.annotation.experimental;
/* renamed from: androidx.annotation.experimental.R */
/* loaded from: classes2.dex */
public final class C0029R {
    private C0029R() {
    }
}
