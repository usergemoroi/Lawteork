package androidx.arch.core;
/* renamed from: androidx.arch.core.R */
/* loaded from: classes2.dex */
public final class C0124R {
    private C0124R() {
    }
}
