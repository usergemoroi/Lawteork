package androidx.appcompat.resources;
/* renamed from: androidx.appcompat.resources.R */
/* loaded from: classes2.dex */
public final class C0065R {

    /* renamed from: androidx.appcompat.resources.R$drawable */
    /* loaded from: classes2.dex */
    public static final class C0066drawable {
        public static final int abc_vector_test = 2131165302;

        private C0066drawable() {
        }
    }

    /* renamed from: androidx.appcompat.resources.R$styleable */
    /* loaded from: classes2.dex */
    public static final class styleable {
        public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
        public static final int AnimatedStateListDrawableCompat_android_dither = 0;
        public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
        public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
        public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
        public static final int AnimatedStateListDrawableCompat_android_visible = 1;
        public static final int AnimatedStateListDrawableItem_android_drawable = 1;
        public static final int AnimatedStateListDrawableItem_android_id = 0;
        public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
        public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
        public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
        public static final int AnimatedStateListDrawableTransition_android_toId = 1;
        public static final int StateListDrawableItem_android_drawable = 0;
        public static final int StateListDrawable_android_constantSize = 3;
        public static final int StateListDrawable_android_dither = 0;
        public static final int StateListDrawable_android_enterFadeDuration = 4;
        public static final int StateListDrawable_android_exitFadeDuration = 5;
        public static final int StateListDrawable_android_variablePadding = 2;
        public static final int StateListDrawable_android_visible = 1;
        public static final int[] AnimatedStateListDrawableCompat = {16843036, 16843156, 16843157, 16843158, 16843532, 16843533};
        public static final int[] AnimatedStateListDrawableItem = {16842960, 16843161};
        public static final int[] AnimatedStateListDrawableTransition = {16843161, 16843849, 16843850, 16843851};
        public static final int[] StateListDrawable = {16843036, 16843156, 16843157, 16843158, 16843532, 16843533};
        public static final int[] StateListDrawableItem = {16843161};

        private styleable() {
        }
    }

    private C0065R() {
    }
}
