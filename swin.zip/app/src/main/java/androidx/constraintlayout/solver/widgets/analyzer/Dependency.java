package androidx.constraintlayout.solver.widgets.analyzer;
/* loaded from: classes.dex */
public interface Dependency {
    void update(Dependency dependency);
}
