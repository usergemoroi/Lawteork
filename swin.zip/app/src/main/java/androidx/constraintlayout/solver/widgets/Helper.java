package androidx.constraintlayout.solver.widgets;
/* loaded from: classes.dex */
public interface Helper {
    void add(ConstraintWidget constraintWidget);

    void removeAllIds();

    void updateConstraints(ConstraintWidgetContainer constraintWidgetContainer);
}
