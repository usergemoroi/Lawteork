package androidx.constraintlayout.motion.widget;
/* loaded from: classes.dex */
public interface Animatable {
    float getProgress();

    void setProgress(float f);
}
