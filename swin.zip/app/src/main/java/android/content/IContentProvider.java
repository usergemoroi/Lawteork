package android.content;

import android.os.IInterface;
/* loaded from: classes.dex */
public interface IContentProvider extends IInterface {
}
