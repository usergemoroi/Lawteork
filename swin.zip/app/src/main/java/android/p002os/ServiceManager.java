package android.p002os;
/* renamed from: android.os.ServiceManager */
/* loaded from: classes.dex */
public class ServiceManager {
    public static IBinder getService(String str) {
        throw new UnsupportedOperationException("STUB");
    }
}
